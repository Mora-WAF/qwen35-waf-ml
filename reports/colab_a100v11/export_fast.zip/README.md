# Qwen3.5-4B WAF/NIDS classifier adapter (fast, pre-evaluation)

rsLoRA adapter for `unsloth/Qwen3.5-4B` @ `3764fa359b9082ea5a1e4a5e3ac3aaf6e9671636`. This is the copy saved right after training. The full model card (data, training, calibrated evaluation, robustness, limitations) is written into the downloaded export by `python -m training.model_card reports/colab_<run>`.
